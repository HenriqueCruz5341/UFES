#include <stdio.h>
#include "jogador.h"

jogador CriaJogador{
  jogador jogador;

  return jogador;
}
