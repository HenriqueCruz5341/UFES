#ifndef JOGADOR_H
#define JOGADOR_H

typedef struct{
  int id;
  float pontos;
  float tempo;
}jogador;


jogador CriaJogador();

#endif
