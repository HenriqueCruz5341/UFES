Para logar como admin use:
Login: admin
Senha: admin

Apenas ele pode adicionar mídias e albuns no sistema.
