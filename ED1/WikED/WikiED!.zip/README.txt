Para compilar: "make compile", será gerado um arquivo 'exec'.
Para rodar: "make run", é importante que o arquivo de entrada tenha o nome 'entrada.txt'.
Para rodar com valgrind: "make valgrind", é importante que o arquivo de entrada tenha o nome 'entrada.txt'.
Para limpar: "make clean", o arquivo 'exec' será apagado.